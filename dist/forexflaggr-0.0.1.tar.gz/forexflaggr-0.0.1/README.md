# forexflaggr

A minimal package to pull and analyze financial (forex) data.

## Getting started

Install `ForexFlaggr` from pip:

```$ pip install forexflaggr```

or alternatively, on GitHub:

```$ pip install git+<url>```

## Usage
